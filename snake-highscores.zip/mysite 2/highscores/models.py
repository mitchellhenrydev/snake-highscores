from django.db import models

class Username(models.Model):
    username_text = models.CharField(max_length=200)
    username_score = models.IntegerField(default=0)
