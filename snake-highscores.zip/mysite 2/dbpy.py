import sqlite3
"""
THIS WORKS

"""
conn = sqlite3.connect("db.sqlite3")
c = conn.cursor()


def data_entry():
    c.execute("SELECT max(id) FROM highscores_username")
    max_id = c.fetchone()[0]
    #if there are no rows, max_id will be "NoneType", and you cant add one to it. So, if thats the case, there must not be any rows in the table yet. Thus, a typerror will be thrown, and we can add the first row with the id 1, rather than whatever the last row was plus one
    try:
        new_id = max_id + 1 
        print("this is the last id in the table:", max_id)
    except TypeError:
        new_id = 1
    c.execute("UPDATE django_content_type SET name='<highscores>' where name='<webapp>' AND app_label='<OldAppName>'")
    conn.commit()
    c.close()
    conn.close()

data_entry()


def data_delete():
    c.execute("SELECT max(id) FROM webapp_username")
    max_id = c.fetchone()[0]
    c.execute("DELETE FROM webapp_username WHERE id=%s" % max_id)
    conn.commit()
    c.close()
    conn.close()

#data_delete()
