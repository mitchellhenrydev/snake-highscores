#!/usr/bin/env python

import pygame
import sys
import time
import random
import sqlite3

from pygame.locals import *

FPS = 20


pygame.init()
fpsClock=pygame.time.Clock()

SCREEN_WIDTH, SCREEN_HEIGHT = 640, 480
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), 0, 32)
surface = pygame.Surface(screen.get_size())
#surface = surface.convert()
#surface.fill((255,255,255))
clock = pygame.time.Clock()

#pygame.key.set_repeat(1, 40)

GRIDSIZE=20
GRID_WIDTH = SCREEN_WIDTH / GRIDSIZE
GRID_HEIGHT = SCREEN_HEIGHT / GRIDSIZE
UP    = (0, -1)
DOWN  = (0, 1)
LEFT  = (-1, 0)
RIGHT = (1, 0)
    
screen.blit(surface, (0,0))

def data_entry(username, score):
    conn = sqlite3.connect("db.sqlite3")
    c = conn.cursor()
    c.execute("SELECT max(id) FROM highscores_username")
    max_id = c.fetchone()[0]
    #if there are no rows, max_id will be "NoneType", and you cant add one to it. So, if thats the case, there must not be any rows in the table yet. Thus, a typerror will be thrown, and we can add the first row with the id 1, rather than whatever the last row was plus one
    try:
        new_id = max_id + 1 
    except TypeError:
        new_id = 1
    c.execute("INSERT INTO highscores_username VALUES(?, ?, ?);", (new_id, username, score))
    conn.commit()
    c.close()
    conn.close()

def draw_box(surf, color, pos):
    r = pygame.Rect((pos[0], pos[1]), (GRIDSIZE, GRIDSIZE))
    pygame.draw.rect(surf, color, r)

class Snake(object):
    def __init__(self):
        self.revive()
        self.color = (0,0,0)
        self.dead = False
        self.username = ""

    def get_head_position(self):
        return self.positions[0]

    def revive(self):
        self.username = ""
        self.length = 1
        self.positions =  [((SCREEN_WIDTH / 2), (SCREEN_HEIGHT / 2))]
        self.direction = random.choice([UP, DOWN, LEFT, RIGHT])

    def point(self, pt):
        if self.length > 1 and (pt[0] * -1, pt[1] * -1) == self.direction:
            return
        else:
            self.direction = pt

    def move(self):
        cur = self.positions[0]
        x, y = self.direction
        new = (((cur[0]+(x*GRIDSIZE)) % SCREEN_WIDTH), (cur[1]+(y*GRIDSIZE)) % SCREEN_HEIGHT)
        if len(self.positions) > 2 and new in self.positions[2:]:
            self.dead = True
        else:
            self.positions.insert(0, new)
            if len(self.positions) > self.length:
                self.positions.pop()
    
    def draw(self, surf):
        for p in self.positions:
            draw_box(surf, self.color, p)

class Apple(object):
    def __init__(self):
        self.position = (0,0)
        self.color = (255,0,0)
        self.randomize()

    def randomize(self):
        self.position = (random.randint(0, GRID_WIDTH-1) * GRIDSIZE, random.randint(0, GRID_HEIGHT-1) * GRIDSIZE)

    def draw(self, surf):
        draw_box(surf, self.color, self.position)

def check_eat(snake, apple):
    if snake.get_head_position() == apple.position:
        snake.length += 1
        apple.randomize()

if __name__ == '__main__':
    snake = Snake()
    apple = Apple()
    while True:
        heldkeys = pygame.key.get_pressed()
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == KEYDOWN:
                if snake.dead == True:
                    if event.key == K_BACKSPACE:
                        snake.username = snake.username[:-1]
                    if len(snake.username) < 18:
                        if event.key == K_1:
                            if heldkeys[pygame.K_1]:
                                pass
                            else:
                                snake.username += '1'
                        if event.key == K_2:
                            if heldkeys[pygame.K_2]:
                                pass
                            else:
                                snake.username += '2'
                        if event.key == K_3:
                            if heldkeys[pygame.K_3]:
                                pass
                            else:
                                snake.username += '3'
                        if event.key == K_4:
                            if heldkeys[pygame.K_4]:
                                pass
                            else:
                                snake.username += '4'
                        if event.key == K_5:
                            if heldkeys[pygame.K_5]:
                                pass
                            else:
                                snake.username += '5'
                        if event.key == K_6:
                            if heldkeys[pygame.K_6]:
                                pass
                            else:
                                snake.username += '6'
                        if event.key == K_7:
                            if heldkeys[pygame.K_7]:
                                pass
                            else:
                                snake.username += '7'
                        if event.key == K_8:
                            if heldkeys[pygame.K_8]:
                                pass
                            else:
                                snake.username += '8'
                        if event.key == K_9:
                            if heldkeys[pygame.K_9]:
                                pass
                            else:
                                snake.username += '9'
                        if event.key == K_0:
                            if heldkeys[pygame.K_0]:
                                pass
                            else:
                                snake.username += '0'
                        if event.key == K_q:
                            if heldkeys[pygame.K_q]:
                                pass
                            else:
                                snake.username += 'q'
                        if event.key == K_w:
                            if heldkeys[pygame.K_w]:
                                pass
                            else:
                                snake.username += 'w'
                        if event.key == K_e:
                            if heldkeys[pygame.K_e]:
                                pass
                            else:
                                snake.username += 'e'
                        if event.key == K_r:
                            if heldkeys[pygame.K_r]:
                                pass
                            else:
                                snake.username += 'r'
                        if event.key == K_t:
                            if heldkeys[pygame.K_t]:
                                pass
                            else:
                                snake.username += 't'
                        if event.key == K_y:
                            if heldkeys[pygame.K_y]:
                                pass
                            else:
                                snake.username += 'y'
                        if event.key == K_u:
                            if heldkeys[pygame.K_u]:
                                pass
                            else:
                                snake.username += 'u'
                        if event.key == K_i:
                            if heldkeys[pygame.K_i]:
                                pass
                            else:
                                snake.username += 'i'
                        if event.key == K_o:
                            if heldkeys[pygame.K_o]:
                                pass
                            else:
                                snake.username += 'o'
                        if event.key == K_p:
                            if heldkeys[pygame.K_p]:
                                pass
                            else:
                                snake.username += 'p'
                        if event.key == K_a:
                            if heldkeys[pygame.K_a]:
                                pass
                            else:
                                snake.username += 'a'
                        if event.key == K_s:
                            if heldkeys[pygame.K_s]:
                                pass
                            else:
                                snake.username += 's'
                        if event.key == K_d:
                            if heldkeys[pygame.K_d]:
                                pass
                            else:
                                snake.username += 'd'
                        if event.key == K_f:
                            if heldkeys[pygame.K_f]:
                                pass
                            else:
                                snake.username += 'f'
                        if event.key == K_g:
                            if heldkeys[pygame.K_g]:
                                pass
                            else:
                                snake.username += 'g'
                        if event.key == K_h:
                            if heldkeys[pygame.K_h]:
                                pass
                            else:
                                snake.username += 'h'
                        if event.key == K_j:
                            if heldkeys[pygame.K_j]:
                                pass
                            else:
                                snake.username += 'j'
                        if event.key == K_k:
                            if heldkeys[pygame.K_k]:
                                pass
                            else:
                                snake.username += 'k'
                        if event.key == K_l:
                            if heldkeys[pygame.K_l]:
                                pass
                            else:
                                snake.username += 'l'
                        if event.key == K_z:
                            if heldkeys[pygame.K_z]:
                                pass
                            else:
                                snake.username += 'z'
                        if event.key == K_x:
                            if heldkeys[pygame.K_x]:
                                pass
                            else:
                                snake.username += 'x'
                        if event.key == K_c:
                            if heldkeys[pygame.K_c]:
                                pass
                            else:
                                snake.username += 'c'
                        if event.key == K_v:
                            if heldkeys[pygame.K_v]:
                                pass
                            else:
                                snake.username += 'v'
                        if event.key == K_b:
                            if heldkeys[pygame.K_b]:
                                pass
                            else:
                                snake.username += 'b'
                        if event.key == K_n:
                            if heldkeys[pygame.K_n]:
                                pass
                            else:
                                snake.username += 'n'
                        if event.key == K_m:
                            if heldkeys[pygame.K_m]:
                                pass
                            else:
                                snake.username += 'm'
                    if event.key == K_SPACE:
                        snake.username += " "
                    if event.key == K_RETURN:
                        data_entry(snake.username, snake.length)
                        snake.dead = False
                        snake.revive()
                        pass
                    elif event.key == K_ESCAPE and snake.dead == True:
                        snake.dead = False
                        snake.revive()
                else:
                    if event.key == K_UP or event.key == K_w:
                        snake.point(UP)
                    elif event.key == K_DOWN or event.key == K_s:
                        snake.point(DOWN)
                    elif event.key == K_LEFT or event.key == K_a:
                        snake.point(LEFT)
                    elif event.key == K_RIGHT or event.key == K_d:
                        snake.point(RIGHT)
                    #elif event.key == K_SPACE and snake.dead == True:
                        #snake.dead = False
                        #snake.revive()
                        
        surface.fill((255,255,255))
        if snake.dead == False:
            snake.move()
            check_eat(snake, apple)
            snake.draw(surface)
            apple.draw(surface)
            font = pygame.font.Font(None, 36)
            text = font.render(str(snake.length), 1, (10, 10, 10))
            textpos = text.get_rect()
            textpos.centerx = 20
            surface.blit(text, textpos)
        else:
            text = font.render("Your score was: %s. Username: %s" % (str(snake.length), snake.username), 1, (10, 10, 10))
            textpos = text.get_rect()
            #textpos.centerx = 20
            surface.blit(text, textpos)
            text_esc = font.render("Press esc if you don't want to save your score", 1, (100, 100, 100))
            text_escpos = text_esc.get_rect(center=(SCREEN_WIDTH/2, SCREEN_HEIGHT/2))
            surface.blit(text_esc, text_escpos)
        screen.blit(surface, (0,0))           
        pygame.display.flip()
        pygame.display.update()
        fpsClock.tick(FPS + snake.length/3)
