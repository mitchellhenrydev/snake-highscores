import sqlite3

conn = sqlite3.connect("db.sqlite3")
c = conn.cursor()

def data_entry():
    c.execute("INSERT INTO webapp_username VALUES(1, 'mitc')")
    conn.commit()
    c.close()
    conn.close()

data_entry()
