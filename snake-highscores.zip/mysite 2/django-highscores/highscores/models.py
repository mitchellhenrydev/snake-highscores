from django.db import models

class Username(models.Model):
    username_text = models.CharField(max_length=200)
    username_score = models.IntegerField(default=0)

"""
class Score(models.Model):
    username = models.ForeignKey(Username)
    score_text = models.IntegerField(default=0)
"""
