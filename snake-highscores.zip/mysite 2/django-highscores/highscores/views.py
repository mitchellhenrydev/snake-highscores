from django.shortcuts import render
from django.template.response import TemplateResponse
from highscores.models import Username

def index(request):
    data = Username.objects.all()
    return TemplateResponse(request, "highscores/index.html", { "data": data })
