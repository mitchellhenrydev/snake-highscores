charstring = "1234567890qwertyuiopasdfghjklzxcvbnm"
charlist = list(charstring)
for i in charlist:
    print("if event.key == K_%s:" % i)
    print("    if heldkeys[pygame.K_%s]:" % i)
    print("        pass")
    print("    else:")
    print("        snake.username += \'%s\'" % i)
    #print("")
